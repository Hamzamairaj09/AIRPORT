﻿using Microsoft.AspNetCore.Mvc;
using AIRPORT.Models;
using AIRPORT.Services;

namespace AIRPORT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PricingController : ControllerBase
    {
        private readonly PricingService _service;

        public PricingController(PricingService service)
        {
            _service = service;
        }

        // GET: api/pricing/seats
        [HttpGet("seats")]
        public IActionResult GetAllSeats()
        {
            return Ok(_service.GetSeats());
        }

        // POST: api/pricing/book
        [HttpPost("book")]
        public IActionResult BookSeat([FromBody] BookingRequest request)
        {
            string result = _service.BookSeat(request.SeatNumber);

            if (result.Contains("Success"))
                return Ok(new { message = result });

            return BadRequest(new { message = result });
        }

        // GET: api/pricing/stats
        [HttpGet("stats")]
        public IActionResult GetStats()
        {
            return Ok(_service.GetStatistics());
        }
    }
}