﻿using Microsoft.AspNetCore.Mvc;
using AIRPORT.Services;
using System.Collections.Generic;

namespace AIRPORT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MultiCityController : ControllerBase
    {
        private readonly TspService _service;

        public MultiCityController(TspService service)
        {
            _service = service;
        }

        [HttpPost("optimize")]
        public IActionResult Optimize([FromBody] List<string> cities)
        {
            var result = _service.OptimizeRoute(cities);
            return Ok(result);
        }
    }
}