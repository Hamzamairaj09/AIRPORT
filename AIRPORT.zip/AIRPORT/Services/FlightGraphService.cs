﻿using AIRPORT.Models;   // <--- UPDATED to match your project
using FlightSearchApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace AIRPORT.Services  // <--- UPDATED to match your project
{
    public class FlightGraphService
    {
        private readonly Dictionary<string, List<FlightEdge>> _flightGraph;

        public FlightGraphService()
        {
            _flightGraph = new Dictionary<string, List<FlightEdge>>();
            LoadMockData();
        }

        // --- Returns list of airports for the Dropdowns ---
        public List<string> GetAvailableAirports()
        {
            return _flightGraph.Keys.ToList();
        }

        // --- Dijkstra Algorithm ---
        public RouteResult GetShortestPath(string start, string end)
        {
            if (!_flightGraph.ContainsKey(start) || !_flightGraph.ContainsKey(end))
                return new RouteResult { Status = "Invalid City Code" };

            var distances = new Dictionary<string, int>();
            var previousNodes = new Dictionary<string, string>();
            var visited = new HashSet<string>();

            // PriorityQueue requires .NET 6+
            var priorityQueue = new PriorityQueue<string, int>();

            foreach (var city in _flightGraph.Keys)
            {
                distances[city] = int.MaxValue;
            }

            distances[start] = 0;
            priorityQueue.Enqueue(start, 0);

            while (priorityQueue.Count > 0)
            {
                if (!priorityQueue.TryDequeue(out string currentCity, out int currentPrice)) break;
                if (currentCity == end) break;
                if (visited.Contains(currentCity)) continue;
                visited.Add(currentCity);

                if (_flightGraph.TryGetValue(currentCity, out var neighbors))
                {
                    foreach (var flight in neighbors)
                    {
                        int newPrice = distances[currentCity] + flight.Price;
                        if (newPrice < distances[flight.To])
                        {
                            distances[flight.To] = newPrice;
                            previousNodes[flight.To] = currentCity;
                            priorityQueue.Enqueue(flight.To, newPrice);
                        }
                    }
                }
            }

            return BuildPath(previousNodes, start, end, distances);
        }

        private RouteResult BuildPath(Dictionary<string, string> previous, string start, string end, Dictionary<string, int> distances)
        {
            if (distances[end] == int.MaxValue)
                return new RouteResult { Status = "No Route Found" };

            var path = new List<string>();
            var current = end;

            while (current != null && current != start)
            {
                path.Add(current);
                previous.TryGetValue(current, out current);
            }
            path.Add(start);
            path.Reverse();

            return new RouteResult { Route = path, TotalPrice = distances[end], Status = "Success" };
        }

        private void LoadMockData()
        {
            AddFlight("KHI", "LHR", 800);
            AddFlight("KHI", "DXB", 300);
            AddFlight("DXB", "LHR", 400);
            AddFlight("KHI", "IST", 250);
            AddFlight("IST", "LHR", 200);
            AddFlight("LHR", "NYC", 600);
        }

        private void AddFlight(string from, string to, int price)
        {
            if (!_flightGraph.ContainsKey(from)) _flightGraph[from] = new List<FlightEdge>();
            if (!_flightGraph.ContainsKey(to)) _flightGraph[to] = new List<FlightEdge>();
            _flightGraph[from].Add(new FlightEdge { From = from, To = to, Price = price });
        }
    }
}