﻿using System;

namespace AIRPORT.Services
{
    public class TspService
    {
        // Wrapper method that the Controller will call
        public int FindMinimumRoute(int[,] graph)
        {
            int n = graph.GetLength(0);
            bool[] visited = new bool[n];
            visited[0] = true;

            // Start from city 0, visiting n cities, count=1, cost=0
            return TspHelper(graph, visited, 0, n, 1, 0, int.MaxValue);
        }

        // Recursive TSP Logic
        private int TspHelper(int[,] graph, bool[] visited, int current,
                              int n, int count, int cost, int minCost)
        {
            // Base case: If all cities visited and there is a path back to start
            if (count == n && graph[current, 0] > 0)
            {
                return Math.Min(minCost, cost + graph[current, 0]);
            }

            // Try to visit every other city
            for (int i = 0; i < n; i++)
            {
                if (!visited[i] && graph[current, i] > 0)
                {
                    visited[i] = true;
                    minCost = TspHelper(graph, visited, i, n,
                                        count + 1,
                                        cost + graph[current, i],
                                        minCost);
                    visited[i] = false; // Backtrack
                }
            }
            return minCost;
        }
    }
}