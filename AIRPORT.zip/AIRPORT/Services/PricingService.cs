﻿using AIRPORT.Models;
using System.Linq;

namespace AIRPORT.Services
{
    public class PricingService
    {
        // We hold the data here (InMemory Database for now)
        private readonly Flight _flight;
        private double _totalRevenue = 0;
        private const double BasePrice = 5000;

        public PricingService()
        {
            // Initialize Mock Data (Flight PK-301 with 20 seats)
            _flight = new Flight { FlightCode = "PK-301" };
            for (int i = 1; i <= 20; i++)
            {
                _flight.Seats.Add(new Seat { SeatNumber = i, IsBooked = false });
            }
        }

        // 1. Get All Seats
        public List<Seat> GetSeats()
        {
            return _flight.Seats;
        }

        // 2. Logic: Calculate Dynamic Price (Knapsack / Demand based)
        private double CalculatePrice(int availableSeats, int totalSeats)
        {
            double demandRatio = (double)(totalSeats - availableSeats) / totalSeats;
            double dynamicPrice = BasePrice + (BasePrice * demandRatio);
            return Math.Round(dynamicPrice, 2);
        }

        // 3. Logic: Book a Seat
        public string BookSeat(int seatNo)
        {
            var seat = _flight.Seats.FirstOrDefault(s => s.SeatNumber == seatNo);

            if (seat == null) return "Invalid Seat Number";
            if (seat.IsBooked) return "Seat Already Booked";

            // Calculate Price before booking
            int available = _flight.Seats.Count(s => !s.IsBooked);
            double finalPrice = CalculatePrice(available, _flight.Seats.Count);

            // Confirm Booking
            seat.IsBooked = true;
            _totalRevenue += finalPrice;

            return $"Success! Seat {seatNo} booked for Rs. {finalPrice}";
        }

        // 4. Logic: Get Statistics
        public BookingStats GetStatistics()
        {
            int available = _flight.Seats.Count(s => !s.IsBooked);
            return new BookingStats
            {
                TotalSeats = _flight.Seats.Count,
                AvailableSeats = available,
                BookedSeats = _flight.Seats.Count - available,
                TotalRevenue = _totalRevenue
            };
        }
    }
}